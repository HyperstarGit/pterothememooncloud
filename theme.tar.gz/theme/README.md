# IceMinecraftTheme

Install script:
```sh
bash <(curl https://raw.githubusercontent.com/Angelillo15/IceMinecraftTheme/main/install.sh)
```